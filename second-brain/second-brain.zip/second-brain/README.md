# Second Brain · Onboarding IT

Assistente documentale in italiano per un team fittizio. Le procedure vivono in Markdown e si possono aprire in Obsidian. AnythingLLM recupera i passaggi pertinenti e rimanda alle fonti. Il modello Qwen3-0.6B gira tramite il server locale di LM Studio.

```mermaid
flowchart LR
    A[Note Markdown in Obsidian] -->|sync.mjs| B[Indice AnythingLLM]
    B -->|Passaggi recuperati| C[Qwen3-0.6B in LM Studio]
    C --> D[Risposta con fonti]
```

## Avvio

1. Installa Node.js 22 o successivo, AnythingLLM Desktop e LM Studio. Apri `notes/` in Obsidian se vuoi modificare le procedure dal vault demo.
2. In LM Studio carica Qwen3-0.6B e avvia il server su `127.0.0.1:1234`. In AnythingLLM seleziona LM Studio come provider e usa `http://127.0.0.1:1234/v1`. Seleziona l’embedder integrato di AnythingLLM e LanceDB per mantenere embeddings e indice sulla macchina.
3. In AnythingLLM crea un workspace demo vuoto in modalità Query e genera una chiave nelle impostazioni Developer API. Controlla l’indirizzo effettivo in cui viene servita la documentazione `/api/docs`.
4. Copia `.env.example` in `.env`. Imposta `ANYTHINGLLM_URL`, `ANYTHINGLLM_WORKSPACE` e `ANYTHINGLLM_API_KEY` con i valori della tua installazione.

```sh
npm test
npm run sync
npm run sync -- --apply
npm run sync -- --apply
```

Il primo comando di sync elenca le differenze rispetto al manifest locale senza contattare il server. Con `--apply` il comando riconcilia l’indice con la cartella, verifica le operazioni via API e aggiorna `.local/sync.json`. L’ultima esecuzione deve mostrare «Nessuna modifica». Prova quindi a chiedere «La VPN non funziona dopo il riavvio: cosa faccio e quali informazioni scrivo nel ticket?».

Il comando può ricevere `--notes <cartella>` e `--state <manifest>`. Usa un manifest distinto per ogni coppia cartella/workspace e conservalo per poter riconciliare modifiche, rinomine e cancellazioni. Le rimozioni si applicano all’indice del workspace. Le vecchie copie possono restare nella raccolta documenti di AnythingLLM. Se il processo viene terminato durante una sincronizzazione, verifica che sia effettivamente chiuso prima di togliere il file `.lock` accanto al manifest e riprova.

## Valutazione

Con un **workspace demo vuoto distinto** da quello usato nei passi precedenti, aggiorna `ANYTHINGLLM_WORKSPACE` ed esegui:

```sh
npm run evaluate
```

Il comando importa una copia delle dieci note, esegue otto prove di consultazione e registra due risposte di partenza. Poi modifica due procedure nella copia, le sincronizza, verifica la seconda esecuzione senza differenze e ripete le due domande. Esegue anche un controllo fuori punteggio su aggiunta, rinomina e rimozione di una fonte. Il JSON in `.local/evaluation-*/results.json` contiene le risposte finali, le fonti recuperate e le durate lato client. La prova lascia il workspace con le procedure aggiornate.

Valuta insieme testo e fonti. Una risposta passa se contiene le informazioni attese senza contraddizioni e se le fonti necessarie contengono i passaggi che la supportano. Per i casi di informazione assente conta il riconoscimento esplicito dell’assenza. La soglia è 8 su 10, comprese entrambe le assenze e i due aggiornamenti. [Domande e criteri](evaluation/cases.json)

Per ripetere soltanto la scena della VPN con Qwen3.5-4B e fino a otto passaggi recuperati, usa `npm run evaluate -- --demo` su un workspace vuoto. Il comando pone la stessa domanda prima e dopo l’aggiunta del nuovo campo al ticket.

[Risultati misurati, risposte e fonti](evaluation/README.md)

## Il vault mostrato nel portfolio

`vault-demo/` contiene le procedure arricchite usate per il video della configurazione locale. Apri la cartella come vault in Obsidian e parti da `Manuale operativo IT.md`. La vista grafo mostra i collegamenti tra le procedure. Per indicizzare queste note in un workspace demo dedicato usa `npm run sync -- --notes vault-demo --state .local/vault-demo-sync.json --apply`.

La suite storica continua a usare `notes/`, la versione del corpus a cui si riferiscono i risultati misurati.
