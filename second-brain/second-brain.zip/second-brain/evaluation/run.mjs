import { randomUUID } from 'node:crypto';
import { cp, mkdir, mkdtemp, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { api, loadConfiguration, synchronize, workspaceDocuments } from '../sync.mjs';

const project = fileURLToPath(new URL('../', import.meta.url));
const cases = JSON.parse(await readFile(new URL('./cases.json', import.meta.url), 'utf8'));
const prompt = 'Rispondi in italiano usando il contesto fornito. Se non contiene la risposta, dichiaralo. ' +
  'Quando la domanda richiede una procedura, riporta i passaggi pertinenti nell’ordine indicato.';
const demoOnly = process.argv.includes('--demo');

async function run() {
  const config = loadConfiguration();
  const send = api(config);
  const workspace = '/workspace/' + config.slug;
  if (workspaceDocuments(await send(workspace), config.slug).length !== 0) {
    throw new Error('La valutazione richiede un workspace demo vuoto dedicato.');
  }
  const local = join(project, '.local');
  await mkdir(local, { recursive: true });
  const directory = await mkdtemp(join(local, 'evaluation-'));
  const root = join(directory, 'notes');
  const reportPath = join(directory, 'results.json');
  const results = { startedAt: new Date().toISOString(), workspace: config.slug, prompt, topN: demoOnly ? 8 : 4, cases: [] };
  const save = () => writeFile(reportPath, JSON.stringify(results, null, 2) + '\n');
  const sync = () => synchronize({
    root, statePath: join(directory, 'sync.json'), config, apply: true, request: send,
  });
  async function question(test, phase) {
    const start = performance.now();
    const entry = { id: test.id, kind: test.kind, phase, question: test.question, expected: test.expected,
      expectedSources: test.sources };
    try {
      const response = await send(workspace + '/chat', {
        message: '/no_think\n' + test.question, mode: 'query', sessionId: randomUUID(),
      });
      if (typeof response.textResponse !== 'string') throw new Error('Risposta testuale mancante.');
      entry.answer = response.textResponse.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
      if (!entry.answer) throw new Error('Risposta finale vuota.');
      entry.sources = (response.sources ?? []).map(({ title, chunk, text }) => ({ title, chunk: chunk ?? text }));
    } catch (error) {
      entry.error = error.message;
    }
    entry.ms = Math.round(performance.now() - start);
    results.cases.push(entry);
    await save();
    console.log(test.id, phase, entry.ms + ' ms', entry.error ?? 'registrata');
  }

  const vpn = cases.find(({ id }) => id === '05');
  async function reviseTicket() {
    const ticket = join(root, 'Ticket ed escalation.md');
    const procedure = await readFile(ticket, 'utf8');
    const line = '- orario approssimativo di inizio del problema.';
    const revised = '- orario approssimativo di inizio del problema;\n- sede dalla quale si lavora.';
    if (!procedure.includes(line)) throw new Error('La procedura ticket è cambiata rispetto al corpus atteso.');
    await writeFile(ticket, procedure.replace(line, revised));
    results.demoChange = { note: 'Ticket ed escalation.md', before: line, after: revised, operations: await sync() };
    await question({ ...vpn, expected: vpn.expected + ' Includere anche la sede dalla quale si lavora.' }, 'demo aggiornata');
  }

  console.log(reportPath);
  await save();
  await cp(join(project, 'notes'), root, { recursive: true });
  await send(workspace + '/update', { openAiPrompt: prompt, openAiTemp: 0, topN: results.topN });
  results.initialSync = await sync();
  await save();
  if (demoOnly) {
    await question(vpn, 'prima');
    await reviseTicket();
    if (results.cases.some(({ error }) => error)) process.exitCode = 1;
    return;
  }
  for (const test of cases.filter(({ change }) => !change)) await question(test, 'valutazione');
  for (const test of cases.filter(({ change }) => change)) await question(test, 'prima');
  for (const { change } of cases.filter(({ change }) => change)) {
    for (const name of [change.file, change.also].filter(Boolean)) {
      const target = join(root, name);
      const content = await readFile(target, 'utf8');
      if (!content.includes(change.before)) throw new Error(`Testo di partenza mancante in ${name}.`);
      await writeFile(target, content.replace(change.before, change.after));
    }
  }
  results.updateSync = await sync();
  results.repeatSync = await sync();
  await save();
  for (const test of cases.filter(({ change }) => change)) await question(test, 'valutazione');

  await reviseTicket();

  const original = 'Codice esemplificativo.md';
  const renamed = 'Verifica codice esemplificativo.md';
  const lifecycle = {
    id: 'indice', kind: 'controllo', question: 'Qual è il codice TURCHESE del collaudo indice secondo la nota di verifica?',
    expected: 'TURCHESE-582.', sources: [original],
  };
  await writeFile(join(root, original), 'Il codice TURCHESE del collaudo indice è TURCHESE-582.');
  results.lifecycle = { add: await sync() };
  await question(lifecycle, 'aggiunta');
  await rename(join(root, original), join(root, renamed));
  results.lifecycle.rename = await sync();
  await question({ ...lifecycle, sources: [renamed] }, 'rinomina');
  await rm(join(root, renamed));
  results.lifecycle.remove = await sync();
  await question({ ...lifecycle, expected: 'Il codice non è disponibile.', sources: [] }, 'rimozione');
  if (results.cases.some(({ error }) => error)) process.exitCode = 1;
}

try {
  await run();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
