# Risultati · 25 novembre 2026

Stesso corpus di dieci note, stessa suite in italiano, modalità Query e quattro passaggi recuperabili. Le prove hanno usato AnythingLLM 1.16.1, l’embedder integrato Xenova/all-MiniLM-L6-v2, LanceDB e LM Studio 0.4.21. Ogni domanda ha una sessione separata. Le durate indicano il tempo lato client per la risposta completa, compreso il ragionamento quando presente. Le registrazioni riportano il testo finale e i passaggi restituiti dall’API.

| Modello | Corrette | Informazioni assenti | Aggiornamenti | Mediana | Soglia |
| --- | ---: | ---: | ---: | ---: | --- |
| [Qwen3-0.6B Q8_0](qwen3-0.6b.json) | 5/10 | 2/2 | 1/2 | 1,04 s | Sotto soglia |
| [Qwen3.5-4B Q4_K_M](qwen3.5-4b.json) | 8/10 | 2/2 | 2/2 | 14,53 s | Raggiunta |

Valutazione manuale contro [risposte attese e documenti richiesti](cases.json). Per le procedure modificate il punteggio considera la risposta dopo il sync e il passaggio aggiornato. Le risposte di partenza restano nella registrazione per evidenziare valori già riportati per errore.

| Prova | 0.6B | 4B |
| --- | --- | --- |
| 01 · Node.js | Corretta | Corretta |
| 02 · Account bloccato | Indica 25 minuti, la procedura iniziale ne indica 15 | Corretta |
| 03 · Responsabile del rilascio | Corretta | Corretta |
| 04 · Approvazione della PR | Si contraddice sul numero di approvazioni | Corretta |
| 05 · VPN e ticket | Elenca i campi, ma prescrive ulteriori tentativi dopo il riavvio | Recupera la procedura VPN e un estratto del ticket privo dei campi, quindi omette l’elenco |
| 06 · Accesso al repository | Omette il nome e introduce verifiche aggiuntive | Indica Giulia Romano come opzione, ma rimanda a una fonte attesa che la ricerca non ha recuperato |
| 07 · Budget hardware | Riconosce l’assenza | Riconosce l’assenza |
| 08 · Giorni di ferie | Riconosce l’assenza | Riconosce l’assenza |
| 09 · Attesa aggiornata | Indica 25 minuti sia prima sia dopo la modifica. Omette il singolo tentativo nella risposta aggiornata | Corretta, da 15 a 25 minuti |
| 10 · Escalation aggiornata | Corretta dopo il sync. La risposta iniziale divaga | Corretta, da 30 a 45 minuti |

Il secondo sync a corpus invariato ha rilevato zero modifiche. Il controllo con il codice fittizio TURCHESE-582 ha mostrato la fonte con il nuovo nome dopo la rinomina. Dopo la rimozione, la fonte e il codice sono spariti dalla risposta del modello di riferimento.

La [prova VPN mirata](demo-vpn.json) usa Qwen3.5-4B e fino a otto passaggi. Ripete la stessa domanda dopo aver aggiunto al ticket la sede dalla quale si lavora. È una prova separata dai punteggi in tabella.
