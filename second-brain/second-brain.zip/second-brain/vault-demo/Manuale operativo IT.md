Base di conoscenza di un team di sviluppo fittizio. Usala per completare l’onboarding e sbloccare i problemi di lavoro più comuni.

## Primi giorni

- [[Benvenuto nel team]] — primo giorno, prima settimana e criteri per considerare concluso l’onboarding.
- [[Ambiente di sviluppo]] — configurazione, verifiche e diagnosi dell’avvio locale.
- [[Flusso di lavoro]] — dalla prima modifica alla revisione e al rilascio.

## Accessi e postazione

- [[Vpn e rete|VPN e rete]] — accesso fuori sede, controlli e condizioni per aprire un ticket.
- [[Accessi e account]] — password, blocchi, autenticazione e permessi.
- [[Postazione e software]] — software approvato e problemi al computer.

## Incidenti e supporto

- [[Problemi IT frequenti]] — da qui parti se il sintomo è ancora generico.
- [[Problemi frequenti]] — errori ricorrenti di Git, Node.js e avvio del progetto.
- [[Ticket ed escalation]] — cosa inviare, quale priorità scegliere e quando chiamare un referente.
- [[Persone e responsabilità]] — chi può sbloccare accessi, sviluppo e rilasci.
