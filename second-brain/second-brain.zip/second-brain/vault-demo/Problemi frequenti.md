  

## Repository non accessibile

  

### Sintomo

  

Il repository non si apre oppure Git restituisce un errore di autorizzazione.

  

### Azione

  

Verificare di avere effettuato l'accesso con l'account aziendale.

  

Se il problema continua, contattare il referente per gli accessi indicato in `Persone e responsabilità`.

  

---

  

## `npm install` fallisce

  

### Sintomo

  

L'installazione delle dipendenze termina con un errore.

  

### Azione

  

1. Verificare di utilizzare Node.js 22 LTS.

2. Chiudere il terminale.

3. Aprire un nuovo terminale nella cartella del progetto.

4. Eseguire nuovamente:

  

```bash

npm install

```

  

Se l'errore continua, contattare il referente tecnico.

  

---

  

## Il progetto non si avvia

  

### Sintomo

  

Il comando `npm run dev` restituisce un errore.

  

### Azione

  

1. Verificare che `npm install` sia terminato correttamente.

2. Verificare che il file `.env` esista.

3. Confrontare il file `.env` con `.env.example`.

4. Riprovare ad avviare il progetto.

  

Se il problema continua, contattare il referente tecnico.

  

---

  

## Credenziali scadute

  

### Sintomo

  

Un servizio aziendale richiede nuovamente l'autenticazione oppure rifiuta l'accesso.

  

### Azione

  

Effettuare nuovamente l'accesso.

  

Se non è possibile recuperare l'accesso, contattare il referente per gli accessi.

  

---

  

## Informazioni volutamente non presenti

  

Questa demo non contiene informazioni su:

  

- budget per l'acquisto di hardware;

- ferie;

- stipendi;

- orari obbligatori di lavoro;

- policy di lavoro da remoto.

  

L'assistente dovrebbe dichiarare che queste informazioni non sono disponibili nei documenti della demo.

## Come riportare un errore di sviluppo

Indica il comando, quale versione di Node.js stai usando e il primo messaggio d’errore significativo. Se l’avvio riesce ma la pagina non si apre, controlla l’indirizzo stampato dal terminale prima di aprire una segnalazione.

Collegamenti · [[Ambiente di sviluppo]] · [[Flusso di lavoro]] · [[Ticket ed escalation]]
