import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rename, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { test } from 'node:test';
import { configuration, synchronize } from '../sync.mjs';

async function fixture(t) {
  const local = fileURLToPath(new URL('../.local/', import.meta.url));
  await mkdir(local, { recursive: true });
  const temp = await mkdtemp(join(local, 'test-'));
  t.after(() => rm(temp, { recursive: true, force: true }));
  const root = join(temp, 'notes');
  await mkdir(root);
  const indexed = new Set(['manual.json']);
  const created = [];
  let failDelete = false;
  const config = configuration({});
  const target = '/workspace/' + config.slug;
  const request = async (path, body) => {
    if (path === target) return { workspace: [{ slug: config.slug, documents: [...indexed].map(docpath => ({ docpath })) }] };
    if (path === '/document/raw-text') {
      const location = body.metadata.title + '-' + created.length + '.json';
      created.push(location);
      return { documents: [{ location }] };
    }
    assert.equal(path, target + '/update-embeddings');
    if (failDelete && body.deletes.length) return {};
    for (const location of body.adds) indexed.add(location);
    for (const location of body.deletes) indexed.delete(location);
    return {};
  };
  const run = (apply = false) => synchronize({
    root, statePath: join(temp, 'local', 'manifest.json'), config, apply, request,
  });
  return { root, run, indexed, created, failDelete: (value) => { failDelete = value; } };
}

test('preview, edition, rename and deletion only affect managed documents', async (t) => {
  const f = await fixture(t);
  const original = join(f.root, 'VPN.md');
  await writeFile(original, 'Versione iniziale\r\n');
  assert.deepEqual(await f.run(), [{ action: 'add', name: 'VPN.md' }]);
  assert.equal(f.created.length, 0);
  await f.run(true);
  await writeFile(original, 'Versione iniziale\n');
  assert.deepEqual(await f.run(true), []);
  await writeFile(original, 'Versione aggiornata');
  assert.deepEqual(await f.run(true), [{ action: 'update', name: 'VPN.md' }]);
  assert.deepEqual([...f.indexed], ['manual.json', f.created[1]]);
  const renamed = join(f.root, 'Rete.md');
  await rename(original, renamed);
  assert.deepEqual(await f.run(true), [{ action: 'add', name: 'Rete.md' }, { action: 'remove', name: 'VPN.md' }]);
  assert.deepEqual([...f.indexed], ['manual.json', f.created[2]]);
  await rm(renamed);
  assert.deepEqual(await f.run(true), [{ action: 'remove', name: 'Rete.md' }]);
  assert.deepEqual([...f.indexed], ['manual.json']);
});

test('retry reconciles versions after an incomplete index update', async (t) => {
  const f = await fixture(t);
  const file = join(f.root, 'VPN.md');
  await writeFile(file, 'Versione iniziale');
  await f.run(true);
  await writeFile(file, 'Versione aggiornata');
  f.failDelete(true);
  await assert.rejects(f.run(true), /non conferma/);
  assert.equal(f.indexed.size, 3);
  f.failDelete(false);
  await f.run(true);
  assert.equal(f.created.length, 2);
  assert.deepEqual([...f.indexed], ['manual.json', f.created[1]]);
  assert.deepEqual(await f.run(true), []);
});

test('disallows a remote endpoint for the local vault', () => {
  assert.throws(() => configuration({ ANYTHINGLLM_URL: 'https://example.com' }), /loopback/);
});
