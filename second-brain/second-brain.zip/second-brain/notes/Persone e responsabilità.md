  

## Referenti del team

  

### Marta Bianchi — Team Lead

  

Responsabilità:

  

- coordinamento del team;

- assegnazione delle attività;

- gestione delle priorità;

- supporto sui dubbi organizzativi.

  

### Luca Ferri — Referente tecnico

  

Responsabilità:

  

- supporto sull'architettura del progetto;

- dubbi tecnici complessi;

- revisione delle modifiche più importanti;

- supporto durante il rilascio.

  

### Giulia Romano — Referente accessi

  

Responsabilità:

  

- accesso al repository;

- problemi con credenziali e permessi;

- accesso agli strumenti interni.

  

Se un nuovo sviluppatore non riesce ad accedere al repository deve contattare Giulia Romano.

  

### Andrea Conti — Responsabile del rilascio

  

Responsabilità:

  

- coordinare i rilasci;

- verificare che le modifiche approvate siano pronte;

- avviare la procedura di rilascio in produzione.

  

## Regola generale

  

Per i problemi tecnici si contatta prima Luca Ferri.

  

Per problemi di accesso o permessi si contatta Giulia Romano.

  

Per dubbi organizzativi o di priorità si contatta Marta Bianchi.