  

## Obiettivo

  

Questa guida descrive cosa deve fare un nuovo sviluppatore durante il primo giorno e la prima settimana nel team.

  

## Primo giorno

  

1. Accedere alla posta aziendale e agli strumenti di comunicazione.

2. Verificare di avere accesso al repository del progetto.

3. Leggere il documento `Persone e responsabilità`.

4. Seguire la procedura descritta in `Ambiente di sviluppo`.

5. Avviare il progetto in locale e verificare che l'applicazione funzioni.

  

## Prima settimana

  

Durante la prima settimana il nuovo sviluppatore deve:

  

- completare la configurazione dell'ambiente locale;

- leggere il documento `Flusso di lavoro`;

- eseguire una piccola modifica di prova;

- aprire una pull request di prova;

- partecipare ad almeno una revisione del codice insieme a un altro sviluppatore.

  

## Obiettivo della prima settimana

  

Alla fine della prima settimana il nuovo sviluppatore deve essere in grado di:

  

- avviare il progetto in locale;

- creare un branch;

- effettuare una modifica;

- aprire una pull request;

- sapere chi contattare in caso di problemi.