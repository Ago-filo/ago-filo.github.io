## Obiettivo

  

Ogni modifica al progetto deve passare attraverso branch, pull request e revisione.

  

## Procedura

  

1. Aggiornare il branch `main`.

2. Creare un nuovo branch per la modifica.

3. Effettuare la modifica richiesta.

4. Verificare in locale che il progetto funzioni.

5. Creare uno o più commit con messaggi chiari.

6. Pubblicare il branch sul repository remoto.

7. Aprire una pull request verso `main`.

8. Richiedere la revisione di almeno un altro sviluppatore.

9. Correggere eventuali problemi segnalati durante la revisione.

10. Attendere l'approvazione della pull request.

11. Dopo l'approvazione, la modifica può essere integrata in `main`.

12. Il rilascio in produzione viene coordinato dal responsabile del rilascio.

  

## Regole

  

- L'autore di una pull request non può approvare da solo la propria modifica.

- È necessaria almeno un'approvazione di un altro sviluppatore.

- Una modifica non approvata non deve essere rilasciata in produzione.

- Il rilascio in produzione non viene avviato direttamente dallo sviluppatore che ha creato la modifica.