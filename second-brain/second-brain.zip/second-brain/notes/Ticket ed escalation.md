## Quando aprire un ticket IT

Aprire un ticket quando:

- un problema impedisce di lavorare;
- una procedura documentata non risolve il problema;
- è necessario installare software non presente nel catalogo aziendale;
- è richiesto un intervento tecnico sulla postazione;
- un servizio aziendale non è disponibile.

## Informazioni da inserire nel ticket

Ogni ticket deve contenere:

- servizio o dispositivo coinvolto;
- descrizione del problema;
- messaggio di errore, se presente;
- operazioni già provate;
- orario approssimativo di inizio del problema.

## Priorità

### Priorità bassa

Problema che non blocca il lavoro e ha una soluzione alternativa.

### Priorità media

Problema che rallenta il lavoro o impedisce una parte delle attività.

### Priorità alta

Problema che impedisce completamente di lavorare o coinvolge più utenti.

## Escalation

Se un ticket ad alta priorità non riceve risposta entro 30 minuti, contattare Luca Ferri.

Se il problema coinvolge accessi, credenziali o permessi, contattare Giulia Romano.

Se il problema riguarda il rilascio in produzione, contattare Andrea Conti.

## Regola

Non classificare come alta priorità un problema che ha una soluzione alternativa funzionante.