## Account aziendale

Ogni dipendente utilizza un account aziendale personale per accedere ai servizi interni.

Le credenziali non devono essere condivise con altri utenti.

## Password scaduta

Se la password è scaduta:

1. aprire il portale di gestione account;
2. scegliere l'opzione per modificare la password;
3. impostare una nuova password;
4. attendere alcuni minuti prima di riprovare l'accesso ai servizi.

Se la modifica non funziona, contattare Giulia Romano, referente per accessi e permessi.

## Account bloccato

Se l'account risulta bloccato dopo troppi tentativi di accesso:

1. non continuare a inserire la password;
2. attendere 15 minuti;
3. riprovare una sola volta con la password corretta.

Se l'account rimane bloccato, contattare Giulia Romano.

## Autenticazione a più fattori

Per alcuni servizi aziendali è richiesta l'autenticazione a più fattori.

Se non arriva il codice:

1. verificare la connessione di rete;
2. controllare che il dispositivo associato sia acceso;
3. riprovare una volta.

Se il problema continua, contattare Giulia Romano.

## Permessi

I permessi ai servizi aziendali vengono assegnati in base al ruolo.

Un dipendente non deve richiedere direttamente permessi amministrativi se non sono necessari per il proprio lavoro.