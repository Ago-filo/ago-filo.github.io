## Non riesco ad accedere a un servizio

1. verificare che username e password siano corretti;
2. controllare se la password è scaduta;
3. riprovare l'accesso una volta;
4. se il problema continua, consultare `Accessi e account`.

## La VPN non funziona

Seguire la procedura descritta in `VPN e rete`.

Se la procedura non risolve il problema, aprire un ticket IT.

## Non riesco a installare un programma

Verificare prima se il programma è disponibile nel catalogo software aziendale.

Se non è disponibile, aprire un ticket IT con nome del software e motivazione.

## Il computer è lento

1. chiudere le applicazioni non necessarie;
2. riavviare il computer;
3. verificare eventuali aggiornamenti;
4. controllare lo spazio libero sul disco.

Se il problema continua, aprire un ticket IT.

## Problema urgente che blocca il lavoro

Aprire un ticket IT con priorità alta.

Inserire nel ticket tutte le informazioni richieste in `Ticket ed escalation`.

Se non arriva risposta entro 30 minuti, contattare Luca Ferri.

## Informazioni non presenti

Questa documentazione non contiene informazioni su:

- acquisto personale di hardware;
- rimborso di dispositivi personali;
- marche di computer assegnate ai dipendenti;
- sostituzione automatica del computer dopo un certo numero di anni;
- utilizzo di software personale non approvato.