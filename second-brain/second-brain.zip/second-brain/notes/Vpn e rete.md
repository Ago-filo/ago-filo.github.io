
## Utilizzo della VPN

La VPN aziendale deve essere utilizzata per accedere a servizi interni quando si lavora fuori dalla rete aziendale.

## La VPN non si connette

Se la VPN non si connette:

1. verificare che la connessione Internet funzioni;
2. chiudere il client VPN;
3. riaprire il client VPN;
4. effettuare nuovamente l'accesso con l'account aziendale;
5. verificare che la password non sia scaduta.

Se il problema continua, riavviare il computer e riprovare.

Se dopo il riavvio la VPN non funziona ancora, aprire un ticket IT.

## VPN dopo il cambio password

Dopo una modifica della password aziendale, la VPN può continuare a utilizzare temporaneamente le vecchie credenziali.

In questo caso:

1. chiudere completamente il client VPN;
2. riaprirlo;
3. inserire la nuova password;
4. riprovare la connessione.

Se non funziona, consultare `Accessi e account`.

## Connessione lenta

Se la VPN è connessa ma molto lenta:

1. verificare la velocità della connessione Internet;
2. disconnettere e riconnettere la VPN;
3. chiudere eventuali applicazioni che utilizzano molta banda.

Se il problema continua per più di 30 minuti e impedisce di lavorare, aprire un ticket IT.