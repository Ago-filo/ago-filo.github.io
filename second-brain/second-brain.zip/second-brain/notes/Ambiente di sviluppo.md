  

## Prerequisiti

  

Per configurare l'ambiente di sviluppo servono:

  

- Git;

- Visual Studio Code;

- Node.js 22 LTS;

- accesso al repository aziendale.

  

## Procedura di configurazione

  

1. Verificare di avere accesso al repository.

2. Clonare il repository sul computer.

3. Aprire la cartella del progetto con Visual Studio Code.

4. Aprire un terminale nella cartella del progetto.

5. Eseguire:

  

```bash

npm install

```

  

6. Creare una copia del file `.env.example` chiamata `.env`.

7. Avviare il progetto con:

  

```bash

npm run dev

```

  

8. Aprire il browser all'indirizzo indicato dal terminale.

9. Verificare che venga visualizzata la pagina iniziale dell'applicazione.

  

## Verifica finale

  

La configurazione è considerata completata quando:

  

- il progetto si avvia senza errori;

- la pagina iniziale è visibile nel browser.

  

## Problemi di accesso

  

Se il repository non è accessibile, non continuare la configurazione.

  

Consultare `Persone e responsabilità` per individuare il referente corretto.