## Software autorizzato

Sulla postazione aziendale possono essere installati solo software necessari per il lavoro e approvati dal team IT.

## Installazione di software

Per installare un nuovo software:

1. verificare se il programma è già presente nel catalogo software aziendale;
2. se presente, installarlo dal catalogo;
3. se non presente, aprire un ticket IT specificando il nome del software e il motivo della richiesta.

Non scaricare software da fonti non ufficiali.

## Aggiornamenti

Il sistema operativo e i software aziendali devono essere mantenuti aggiornati.

Gli aggiornamenti proposti automaticamente possono essere installati, salvo diversa comunicazione del team IT.

## Computer lento

Se il computer è molto lento:

1. chiudere le applicazioni non necessarie;
2. riavviare il computer;
3. verificare se sono in corso aggiornamenti;
4. controllare di avere spazio libero sul disco.

Se il problema continua dopo il riavvio, aprire un ticket IT.

## Problemi hardware

In caso di problemi hardware evidenti, come tastiera non funzionante, schermo danneggiato o computer che non si accende, non tentare riparazioni autonome.

Aprire un ticket IT descrivendo il problema.