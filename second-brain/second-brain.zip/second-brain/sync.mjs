import { createHash, randomUUID } from 'node:crypto';
import { mkdir, open, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from 'node:process';
import { parseArgs } from 'node:util';

const project = fileURLToPath(new URL('.', import.meta.url));
const hash = (text) => createHash('sha256').update(text).digest('hex');

export function configuration(env = process.env) {
  const url = new URL(env.ANYTHINGLLM_URL || 'http://127.0.0.1:3001');
  if (!['http:', 'https:'].includes(url.protocol) ||
      !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname) ||
      url.username || url.password || url.search || url.hash || !['/', '/api', '/api/'].includes(url.pathname)) {
    throw new Error('ANYTHINGLLM_URL deve puntare a un server loopback.');
  }
  const slug = env.ANYTHINGLLM_WORKSPACE || 'second-brain-demo';
  if (!/^[a-z0-9][a-z0-9_-]*$/.test(slug)) throw new Error('Slug del workspace non valido.');
  return { base: url.origin + '/api/v1', slug, key: env.ANYTHINGLLM_API_KEY };
}

export function api(config) {
  if (!config.key) throw new Error('Imposta ANYTHINGLLM_API_KEY nel file .env.');
  return async (path, body) => {
    const response = await fetch(config.base + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { Authorization: 'Bearer ' + config.key, 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'error',
      signal: AbortSignal.timeout(180_000),
    });
    if (!response.ok) throw new Error(`${path} → HTTP ${response.status}`);
    const data = await response.json();
    if (data.success === false || data.type === 'abort' || data.error) {
      throw new Error(`${path} → ${data.error || data.message || 'operazione rifiutata'}`);
    }
    return data;
  };
}

export function workspaceDocuments(result, slug) {
  const { workspace } = result;
  const match = Array.isArray(workspace) ? workspace.find((item) => item.slug === slug) : workspace;
  if (!Array.isArray(match?.documents)) throw new Error('Elenco documenti del workspace assente.');
  return match.documents;
}

async function notes(root, prefix = '') {
  const found = [];
  const entries = await readdir(join(root, prefix), { withFileTypes: true });
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    if (entry.name.startsWith('.')) continue;
    const name = prefix ? prefix + '/' + entry.name : entry.name;
    if (entry.isDirectory()) found.push(...await notes(root, name));
    if (!entry.isFile() || !name.toLowerCase().endsWith('.md')) continue;
    const content = (await readFile(join(root, name), 'utf8')).replace(/\r\n/g, '\n');
    if (!content.trim()) throw new Error(`Nota vuota: ${name}`);
    found.push({ name, content, digest: hash(content) });
  }
  return found;
}

export async function synchronize({ root, statePath, config, apply = false, request }) {
  const target = config.base + '/workspace/' + config.slug;
  const read = async () => {
    const saved = JSON.parse(await readFile(statePath, 'utf8').catch((error) => {
      if (error.code !== 'ENOENT') throw error;
      return JSON.stringify({ version: 1, target, files: {} });
    }));
    if (saved.version !== 1 || saved.target !== target || !saved.files || typeof saved.files !== 'object') {
      throw new Error('Manifest non valido per questo server e workspace.');
    }
    return saved;
  };
  const write = async (state) => {
    const temporary = statePath + '.' + randomUUID();
    await writeFile(temporary, JSON.stringify(state, null, 2) + '\n', { flag: 'wx' });
    await rename(temporary, statePath);
  };
  const run = async () => {
    const state = await read();
    const workspace = '/workspace/' + config.slug;
    const entries = await notes(root);
    const current = new Set(entries.map(({ name }) => name));
    const operations = [];
    const send = apply ? request ?? api(config) : null;
    const remote = async () => {
      const documents = workspaceDocuments(await send(workspace), config.slug);
      return new Set(documents.map((document) => document.docpath));
    };
    let indexed = apply ? await remote() : null;
    const update = async (adds, deletes) => {
      await send(workspace + '/update-embeddings', { adds, deletes });
      indexed = await remote();
      if (adds.some((item) => !indexed.has(item)) || deletes.some((item) => indexed.has(item))) {
        throw new Error('Il workspace non conferma la modifica all’indice. Ripeti il comando per riprendere.');
      }
    };
    for (const { name, content, digest } of entries) {
      const versions = state.files[name] ?? [];
      let existing = versions.find((version) => version.digest === digest);
      if (versions.length === 1 && existing && (!apply || indexed.has(existing.location))) continue;
      operations.push({ action: versions.length ? 'update' : 'add', name });
      if (!apply) continue;
      if (!existing) {
        const uploaded = await send('/document/raw-text', { textContent: content, metadata: { title: name } });
        const location = uploaded.documents?.[0]?.location;
        if (uploaded.documents?.length !== 1 || !location) throw new Error(`Upload senza posizione valida: ${name}`);
        existing = { digest, location };
        state.files[name] = [...versions, existing];
        await write(state);
      }
      if (!indexed.has(existing.location)) await update([existing.location], []);
      const obsolete = versions.filter((version) => version !== existing && indexed.has(version.location));
      if (obsolete.length) await update([], obsolete.map((version) => version.location));
      state.files[name] = [existing];
      await write(state);
    }
    for (const [name, versions] of Object.entries(state.files)) {
      if (current.has(name)) continue;
      operations.push({ action: 'remove', name });
      if (!apply) continue;
      const locations = versions.map((version) => version.location).filter((location) => indexed.has(location));
      if (locations.length) await update([], locations);
      delete state.files[name];
      await write(state);
    }
    return operations;
  };
  if (!apply) return run();
  await mkdir(dirname(statePath), { recursive: true });
  const lockPath = statePath + '.lock';
  const lock = await open(lockPath, 'wx').catch((error) => {
    if (error.code === 'EEXIST') throw new Error(`Sincronizzazione già in corso: ${lockPath}`);
    throw error;
  });
  try {
    return await run();
  } finally {
    await lock.close();
    await rm(lockPath);
  }
}

export function loadConfiguration() {
  try {
    loadEnvFile(join(project, '.env'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  return configuration();
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const { values } = parseArgs({ options: {
      apply: { type: 'boolean' }, notes: { type: 'string' }, state: { type: 'string' },
    } });
    const operations = await synchronize({
      root: values.notes ? resolve(values.notes) : join(project, 'notes'),
      statePath: values.state ? resolve(values.state) : join(project, '.local', 'sync.json'),
      config: loadConfiguration(),
      apply: values.apply ?? false,
    });
    for (const { action, name } of operations) console.log(`${action}\t${name}`);
    console.log(operations.length ? (values.apply ? 'Sincronizzazione verificata.' : 'Anteprima. Usa --apply per applicare.') : 'Nessuna modifica.');
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
